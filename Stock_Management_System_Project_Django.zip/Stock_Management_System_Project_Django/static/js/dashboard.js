$(document).ready(function () {
    $("#calendar").fullCalendar({

    })
})